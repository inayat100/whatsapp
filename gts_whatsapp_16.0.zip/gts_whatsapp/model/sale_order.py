from odoo import fields,models
import base64
class SaleOrder(models.Model):
    _inherit = "sale.order"

    def testing(self):
        pdf = self.env['ir.actions.report']._render_qweb_pdf('sale.report_saleorder', self.id)

        ctx = {
            'default_pdf_file': base64.b64encode(pdf[0]).decode('utf-8'),
            'default_filename': f"{self.name}.pdf",
            'default_partner_ids': self.partner_id.ids,
            'default_name': f"{self.company_id.name} Quotation (Ref {self.name})",
            'default_body': f"""
Hello,

Your quotation {self.name} amounting in {self.company_id.currency_id.symbol}{self.amount_total} is ready for review.

Do not hesitate to contact us if you have any questions.

--
{self.user_id.name}
        """
        }

        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'send.by.whatsapp',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx
        }




        # pdf_content, __ = self.env["ir.actions.report"].with_user(public_user).sudo()._render_qweb_pdf(
        #     'sign.action_sign_request_print_logs',
        #     self.ids,
        #     data={'format_date': format_date, 'company_id': self.communication_company_id}
        # )

        # attachment_log = self.env['ir.attachment'].create({
        #     'name': "Certificate of completion - %s.pdf" % time.strftime('%Y-%m-%d - %H:%M:%S'),
        #     'raw': pdf_content,
        #     'type': 'binary',
        #     'res_model': self._name,
        #     'res_id': self.id,
        # })
        # attachment = self.env['ir.attachment']
        # is_report = attachment.search([('name','=',f"{self.name}.pdf"),('res_id','=',self.id),('res_model','=','sale.order')],order="create_date desc", limit=1)
        # if not is_report:
        # data = {
        # "name": f"{self.name}.pdf",
        # "type": 'binary',
        # "res_model": 'sale.order',
        # "res_id":self.id,
        # "datas":base64.b64encode(pdf[0]).decode('utf-8'),
        # "public":True
        # }
        # is_report = attachment.create(data)
        # print("==",pdf)
        # pdf = self.env['ir.actions.report'].sudo().get_pdf([3],"")
        # obj = self.env['ir.actions.report'].browse(365)
        # pdf_content = self.get_xml_tree_from_string(obj._render_qweb_pdf(self.id)[0])
        # print("self----",obj.id)
        # pdf_content, content_type = obj._render_qweb_pdf(3)
        # print("11111111111",pdf_content)
        # print("22222222222",content_type)
        # pdf2 = self.env.ref('gts_whatsapp.sale_order_my_report').render_qweb_pdf(self.id)
        # print("-===========",pdf2)
        # sale_obj = self.env['account.move'].search([])
        # print("--=-=-",self.read())
        # print("--=-7777777777777777=-",self.read()[0])
        # data = {
        #     'form':self.read()[0]
        # }
        # retu = self.env.ref('gts_whatsapp.my_report_report').report_action(self)
        # print("=====",retu)
        # return retu
        # for i in sale_obj:
        #     try:
        #         pdf = self.env.ref('account.account_invoices').report_action(self,data=data)
        #         pdf = self.env.ref('account.account_invoices').render_qweb_pdf(i.id)
        #         # pdf = self.env.ref('sale.action_report_saleorder').sudo()._render_qweb_pdf(i.id)
        #         print("-----", pdf)
        #     except:
        #         print("nonon----",i.id)
            # print("-----",pdf2)
        # p = "test.pdf"
        # with open(p, 'wb') as output_file:
        #     output_file.write(pdf[0])

        # attachment = self.env['ir.attachment']
        # attachment.create({
        #     "name": f"{self.name}.pdf",
        #     "type": 'binary',
        #     "res_model": 'sale.order',
        #     "res_id":self.id,
        #     "datas":base64.b64encode(pdf[0]).decode('utf-8'),
        #     "public":True
        # })
        # 'default_att_ids': is_report.ids,
