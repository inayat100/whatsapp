from odoo import fields,models
import base64


class AccountMove(models.Model):
    _inherit = "account.move"

    def send_by_whatsapp(self):
        print("============== account move",self.company_id.currency_id.symbol)

        pdf = self.env['ir.actions.report']._render_qweb_pdf('account.report_invoice_with_payments', self.id)

        ctx = {
            'default_pdf_file': base64.b64encode(pdf[0]).decode('utf-8'),
            'default_filename': f"{self.name}.pdf",
            'default_partner_ids': self.partner_id.ids,
            'default_name': f"{self.company_id.name} Quotation (Ref {self.name})",
            'default_body': f"""
Dear {self.partner_id.name},

Here is your invoice {self.name} amounting in {self.company_id.currency_id.symbol}{self.amount_total} from {self.company_id.name}. Please remit payment at your earliest convenience.

Please use the following communication for your payment: {self.name}.

Do not hesitate to contact us if you have any questions.
        """
        }



        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'send.by.whatsapp',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx

        }