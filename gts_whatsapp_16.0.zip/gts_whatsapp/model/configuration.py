from  odoo import fields,api,models,_
import requests
from odoo.exceptions import ValidationError


class WhatsppConfiguration(models.Model):
    _name = "whatsapp.configuration"

    access_token = fields.Char("Access Token",copy=False)
    phone_number_id = fields.Char("Phone Number ID",copy=False)
    mobile = fields.Char("Mobile Number")
    is_active = fields.Boolean("Active",copy=False)

    @api.onchange('is_active')
    def _onchange_active(self):
        for rec in self:
            if rec.is_active:
                obj = self.env['whatsapp.configuration'].search([('id','!=',rec._origin.id)])
                for i in obj:
                    i.is_active = False

    def check_token(self):
        obj = self.env['whatsapp.configuration'].search([('is_active', '!=', False)])
        url = f"https://graph.facebook.com/v17.0/{obj.phone_number_id}/messages"

        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {obj.access_token}"
        }
        body = {
            "messaging_product": "whatsapp",
            "preview_url": False,
            "recipient_type": "individual",
            "to": obj.mobile,
            "type": "text",
            "text": {
                "body": "This is Connection Testing Message"
            }
        }
        response = requests.post(url, headers=headers, json=body)
        print("response ----",response.status_code)
        if not response.status_code <= 200:
            raise ValidationError("connection Failed")
        else:
            return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('success'),
                        'message': 'connection has been established',
                        'sticky': True,
                    }
                }




