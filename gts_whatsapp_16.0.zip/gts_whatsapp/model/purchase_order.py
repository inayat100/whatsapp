from  odoo import fields ,models ,api
import base64

class PurchaseOrder(models.Model):
    _inherit = "purchase.order"

    def send_by_whatsapp(self):
        pdf = self.env['ir.actions.report']._render_qweb_pdf('purchase.report_purchasequotation', self.id)

        ctx = {
            'default_pdf_file': base64.b64encode(pdf[0]).decode('utf-8'),
            'default_filename': f"{self.name}.pdf",
            'default_partner_ids': self.partner_id.ids,
            'default_name': f"{self.company_id.name} Quotation (Ref {self.name})",
            'default_body': f"""
Dear {self.partner_id.name}

Here is in attachment a request for quotation {self.name} from {self.company_id.name}.

If you have any questions, please do not hesitate to contact us.

Best regards,

--
{self.user_id.name}
        """
        }
        return {
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'send.by.whatsapp',
            'views': [(False, 'form')],
            'view_id': False,
            'target': 'new',
            'context': ctx

        }