from odoo import models,fields
from bs4 import BeautifulSoup
import requests
from odoo.exceptions import ValidationError



class SendByWhatsapp(models.TransientModel):
    _name = "send.by.whatsapp"

    partner_ids = fields.Many2many("res.partner",string="Recipients")
    name = fields.Char("Header")
    body = fields.Text("Body")
    pdf_file = fields.Binary("PDF Report")
    filename = fields.Char()
    att_ids = fields.Many2many(
        'ir.attachment', 'whatsapp_message_ir_attachments_rel',
        'wizard_id', 'attachment_id', 'Attachments')


    def document_send(self,url,headers,number):
        active_id = self.env.context.get('active_id')
        active_model = self.env.context.get('active_model')
        obj = self.env[active_model].browse(active_id)
        attachment = self.env['ir.attachment']
        base_url = self.env['ir.config_parameter'].sudo().search([('key', '=', 'web.base.url')])

        if self.pdf_file:
            attachment_obj = attachment.create({
                "name": f"{obj.name}",
                "type": 'binary',
                "res_model": 'sale.order',
                "res_id": obj.id,
                "datas": self.pdf_file,
                "public": True
            })

            if attachment_obj.local_url:
                doc_link = base_url.value + attachment_obj.local_url
                doct = {
                    "messaging_product": "whatsapp",
                    "preview_url": False,
                    "recipient_type": "individual",
                    "to": "918171415434",
                    "type": "document",
                    "document": {
                        # "link": doc_link,
                        "filename": f"{attachment_obj.name}",
                        "link": "https://d2cyt36b7wnvt9.cloudfront.net/exams/wp-content/uploads/2021/03/15164528/Multiplication-Tables-1-to-100.pdf"
                    }
                }
                response = requests.post(url, headers=headers, json=doct)
                if not response.status_code <= 200:
                    return False
            return True
    def text_send(self,url,headers,number):

        body = {
            "messaging_product": "whatsapp",
            "preview_url": False,
            "recipient_type": "individual",
            "to": "918171415434",
            "type": "text",
            "text": {
                "body": f"*{self.name}*\n{self.body}"
            }
        }
        response = requests.post(url, headers=headers, json=body)
        return response

    def send_whatsapp(self):
        active_id = self.env.context.get('active_id')
        active_model = self.env.context.get('active_model')
        obj = self.env[active_model].browse(active_id)
        conf_obj = self.env['whatsapp.configuration'].search([('is_active', '!=', False)])
        if conf_obj:
            url = f"https://graph.facebook.com/v17.0/{conf_obj.phone_number_id}/messages"
            headers = {
                "Content-Type": "application/json",
                "Authorization": f"Bearer {conf_obj.access_token}"
            }


            for partner in self.partner_ids:
                if partner.mobile:
                    for phone in partner.mobile.split(','):
                        number = phone.strip(' ')
                        self.text_send(url,headers,number)
                        # self.document_send(url,headers,number)
        else:
            raise ValidationError("You should contact administrator / or Check Whatsapp Configuration Credentials")











 # for at in self.att_ids:
            #     attachment_obj = attachment.create({
            #         "name": f"{at.name}",
            #         "type": 'binary',
            #         "res_model": 'sale.order',
            #         "res_id": obj.id,
            #         "datas": at.datas,
            #         "public": True
            #     })
            #     if attachment_obj.local_url:
            #         doc_link = base_url.value + attachment_obj.local_url
            #         doct = {
            #             "messaging_product": "whatsapp",
            #             "preview_url": False,
            #             "recipient_type": "individual",
            #             "to": "918171415434",
            #             "type": "document",
            #             "document": {
            #                 # "link": doc_link
            #                 "filename": f"{attachment_obj.name}",
            #                 "link": "https://d2cyt36b7wnvt9.cloudfront.net/exams/wp-content/uploads/2021/03/15164528/Multiplication-Tables-1-to-100.pdf"
            #             }
            #         }
            #         response = requests.post(url, headers=headers, json=doct)
            #         if not response.status_code <= 200:
            #             return False
