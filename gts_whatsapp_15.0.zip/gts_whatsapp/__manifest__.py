{
    'name': 'Gts Whatapp',
    'version': '16.0',
    'website': "geotechnosoft.com",
    'image': [],
    'depends': ['sale','account','base','purchase'],
    'author': "inayat",
    'description': "",
    'data': [
        "security/ir.model.access.csv",
        "security/group_file.xml",
        "wizard/send_by_whatsapp.xml",
        "views/whatsapp_config.xml",
        "views/sale_order.xml",
        "views/account_move.xml",
        "views/purchase_order.xml",


    ],
    'license': 'LGPL-3',

    'installable': True,
    'auto_install': False,
    'active': False,
}



# permanent_tokrn = "	EAADW4JdLafUBAJEcIO3gQOAmZCXyJ0mLd2Jqlg5KaMkqOfZBbzLPduWu7ABH9ZBgUP5SxWEXOC6Cqe0cDGzZAS6rsVOIoWCYXqnP5RbZBeAPh1aqG8BarVJMGFMAhZBClv5TrSAY0FrXkr5ceeIX5nrjofHtqUauW3Go3MZCyirla9ldihXl1qp"
